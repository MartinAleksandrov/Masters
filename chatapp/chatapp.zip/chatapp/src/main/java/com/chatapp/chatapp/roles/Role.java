package com.chatapp.chatapp.roles;

public enum Role {
    OWNER,
    ADMIN,
    MEMBER
}
